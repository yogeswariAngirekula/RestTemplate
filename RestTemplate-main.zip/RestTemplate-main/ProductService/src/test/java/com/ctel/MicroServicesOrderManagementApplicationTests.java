package com.ctel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServicesOrderManagementApplicationTests {

	@Test
	void contextLoads() {
	}
	
	

}
